import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-tdform',
  templateUrl: './tdform.component.html',
  styleUrls: ['./tdform.component.scss']
})
export class TdformComponent implements OnInit {

  @ViewChild ('form', {static:true}) form!: NgForm;

  userForm = {
    nome : '',
    alterEgo: '',
    superPoteri: '',
    pianeta: ''

  }

  hero: any = {
    nome: '',
    alterEgo: '',
    superPoteri: '',
    nemico: '',
    pianeta: '',
    debolezza: ''

  }

  constructor() { }

  ngOnInit(): void {

    this.form.statusChanges?.subscribe(status => {
      console.log('Stato del form:', status);
    });
  }

  generateNome(){
    this.form.form.patchValue({
      userInfo:{
        nome: 'pippo',
        alterEgo: 'pippo',
        pianeta: 'pippo'
      }
    });
  }


  submit() {
    console.log('Form inviato:', this.form);
    this.hero.nome = this.form.value.userInfo.nome;
    this.hero.alterEgo = this.form.value.userInfo.alterEgo;
    this.hero.superPoteri = this.form.value.userInfo.superPoteri;
    this.hero.nemico = this.form.value.userInfo.nemico;
    this.hero.pianeta = this.form.value.userInfo.pianeta;
    this.hero.debolezza = this.form.value.userInfo.debolezza;
    console.log(this.hero);


    this.form.reset()
  }
}



